Scrub({
    target: "#demo1",
    src: ['../images_icons/with.png','../images_icons/without.png'],
    height: 300
});