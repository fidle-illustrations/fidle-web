from django.apps import AppConfig


class WhiteappConfig(AppConfig):
    name = 'whiteApp'
