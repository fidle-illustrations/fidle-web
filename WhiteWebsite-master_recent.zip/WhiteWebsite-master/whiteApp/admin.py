from django.contrib import admin
from .models import ContactForm

admin.site.register(ContactForm)
